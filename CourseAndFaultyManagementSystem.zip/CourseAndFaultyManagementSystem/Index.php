<!DOCTYPE html>
<html lang="en">
<?php include 'includes/head.php';?>

<body >
    <!-- Page header -->
    <div class="container-fluid" style="
    background-color: #b1cbf1;
">
        <div class="page-header">
            <div class="logo"><a href="index-2.html" title=""><img src="images/logo.png" alt=""></a></div>
        </div>
    </div>
    <!-- /page header -->
    

    <!-- Page container -->
    <div class="page-container container-fluid" >    
        <!-- Page content -->
        <div class="row">            
           <div class="row" style="background-image:url(images/background.png); background-size: cover;">
               
            <div  style="width: 400px; margin: auto;  " >
               <br>
               <br>
               <br>
               <br>
               <br>
               <br>
               <br>
                <div class="panel panel-default">
                    <div class="panel-heading"><h6 class="panel-title">Choose Admin/Faculty</h6></div>
                    <br>
                    <a class="btn btn-block" href="admin_signin.php">Admin</a>
                    <a class="btn btn-block" href="faculty_signin.php">Faculty</a>                 
                </div>
            </div>
              <br>
               <br>
               <br>
               <br>
               <br>
           </div>

            <!-- Footer -->
            <div class="footer">
                &copy; Copyright 2019. All rights reserved.
            </div>
            <!-- /footer -->

        </div>
    </div>

</body>

</html>
