<?php
	$server="localhost";
	$username="root";
	$password="";
	$database="course_and_faculty_management_system";
	
	$conn=mysqli_connect($server,$username,$password,$database);
?>