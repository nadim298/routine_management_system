<div class="footer">
                &copy; Copyright 2019. All rights reserved.
            </div>