<?php include 'includes/session.php';?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>
<style type="text/css">
    hr {
    margin-top: 2px;
    margin-bottom: 2px;
    border: 0;
    border-top: 1px solid #eee;
}
</style>
<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
        	<div class="page-title">
                <h5><i class="fa fa-bars"></i>Choices</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading"><h6 class="panel-title">All Course Choices of All Faculties</h6>
                <a href="AutoAssignCourse.php" id="auto_assignBtn" class="pull-right btn btn-success">Auto Assign</a>
                </div>
                <div class="datatable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Faculty Name</th>
                                <th>Theory Courses</th>
                                <th>Day</th>
                                <th style="text-align: center;">8:00am <br>
                                    To <br>
                                 1:00pm
                                </th>
                                <th style="text-align: center;">1:00pm <br>
                                    To <br>
                                6:00pm</th>
                                <th>Updated date</th>
                            </tr>
                        </thead>
                         <tbody>  
                         <?php 
                         $select_choiceRequest=mysqli_query($conn,"SELECT tblrequests.Faculty_ID, tblfaculty.Name FROM tblrequests INNER JOIN tblfaculty ON tblrequests.Faculty_ID=tblfaculty.id where Session='$trimester_id' GROUP by tblrequests.Faculty_ID");              
                                            if(mysqli_num_rows($select_choiceRequest)>0){
                                                while($select_choiceRequest_row=mysqli_fetch_array($select_choiceRequest)){
                                                    $Faculty_ID=$select_choiceRequest_row["Faculty_ID"];
                                                    $Name=$select_choiceRequest_row["Name"];

                                                 $DayWithShift1="";   
                                                 $DayWithShift2="";   
                                                 $DayWithShift_Count=1;   
        $select_DayWithShift=mysqli_query($conn,"SELECT * FROM `tblfaculty_offdaychoice` WHERE Faculty_Id='$Faculty_ID' AND Session='$trimester_id'");              
                                if(mysqli_num_rows($select_DayWithShift)>0){
                                    while($select_DayWithShift_row=mysqli_fetch_array($select_DayWithShift)){
                                        ${"DayWithShift" . $DayWithShift_Count}=$select_DayWithShift_row["DayWithShift"];
                                        $DayWithShift_Count=$DayWithShift_Count+1;
                                    }
                                }
     
                                                    ?>
                                                    <tr>
                                <td><?php echo $Faculty_ID; ?></td>
                                <td><?php echo $Name; ?></td>
                                
                                <td>
                                    <select class="getCourses" name="ChoiceNo1" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo1_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=1 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo1_row=mysqli_fetch_array($ChoiceNo1_cmd);
                                        $ChoiceNo1=$ChoiceNo1_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo1; ?></option>
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo2" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo2_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=2 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo2_row=mysqli_fetch_array($ChoiceNo2_cmd);
                                        $ChoiceNo2=$ChoiceNo2_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo2; ?></option>
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo3" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo3_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=3 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo3_row=mysqli_fetch_array($ChoiceNo3_cmd);
                                        $ChoiceNo3=$ChoiceNo3_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo3; ?></option>
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo4" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo4_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=4 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo4_row=mysqli_fetch_array($ChoiceNo4_cmd);
                                        $ChoiceNo4=$ChoiceNo4_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo4; ?></option>
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo5" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo5_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID'   and ChoiceNo=5 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo5_row=mysqli_fetch_array($ChoiceNo5_cmd);
                                        $ChoiceNo5=$ChoiceNo5_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo5; ?></option>
                                    </select>
                                </td>
                                <td>
                                    Saturday <hr>
                                    Sunday <hr>
                                    Monday <hr>
                                    Tuesday <hr>
                                    Wednesday <hr>
                                    Thursday
                                </td>
                                <td style="text-align: center;">
                                    <input type="checkbox" name="DayWithShift[]" value="Saturday-1" <?php if($DayWithShift1=="Saturday-1"|| $DayWithShift2=="Saturday-1"){ echo "checked";} ?>
                                    ><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Sunday-1" <?php if($DayWithShift1=="Sunday-1"|| $DayWithShift2=="Sunday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Monday-1" <?php if($DayWithShift1=="Monday-1"|| $DayWithShift2=="Monday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Tuesday-1" <?php if($DayWithShift1=="Tuesday-1"|| $DayWithShift2=="Tuesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Wednesday-1" <?php if($DayWithShift1=="Wednesday-1"|| $DayWithShift2=="Wednesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Thursday-1" <?php if($DayWithShift1=="Thursday-1"|| $DayWithShift2=="Thursday-1"){ echo "checked";} ?>><br>
                                </td>
                                <td style="text-align: center;">
                                    <input  type="checkbox" name="DayWithShift[]" value="Saturday-2" <?php if($DayWithShift1=="Saturday-2"|| $DayWithShift2=="Saturday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Sunday-2" <?php if($DayWithShift1=="Sunday-2"|| $DayWithShift2=="Sunday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Monday-2" <?php if($DayWithShift1=="Monday-2"|| $DayWithShift2=="Monday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Tuesday-2" <?php if($DayWithShift1=="Tuesday-2"|| $DayWithShift2=="Tuesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Wednesday-2" <?php if($DayWithShift1=="Wednesday-2"|| $DayWithShift2=="Wednesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Thursday-2" <?php if($DayWithShift1=="Thursday-2"|| $DayWithShift2=="Thursday-2"){ echo "checked";} ?>><br>
                                </td>
                                <td></td>
                            </tr>
                                                    <?php
                                                }
                                            }
                          ?>                         
                            
                            
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>

<script type="text/javascript">
$('input[type=checkbox]').prop('disabled', true);
</script>

<script type="text/javascript">
    $('#auto_assignBtn').on('click', function () {
        <?php 
        $check_assignedCourse_cmd=mysqli_query($conn,"SELECT * FROM `tblassignedcourses` WHERE Session='$trimester_id'");

            if(mysqli_num_rows($check_assignedCourse_cmd)>0){
                ?>
                return confirm('Are you sure?');
                <?php
            }
     ?>
        
    });
    
</script>