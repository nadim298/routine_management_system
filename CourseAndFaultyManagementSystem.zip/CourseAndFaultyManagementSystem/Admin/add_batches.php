<?php include 'includes/session.php';?>
 <?php
if(isset($_POST['add']))
{
$Batch=$_POST['Batch'];
$Section=$_POST['Section'];
$Faculty=$_POST['Faculty'];

$conditionCheck=0;

//$lettersArray = array("A", "B", "C", "D","E","F","G","H","I","J");

//check batch already exist
$result=mysqli_query($conn,"SELECT COUNT(*) as batchCount FROM `tblbatches` WHERE Batch=$Batch AND Section='$Section'");
$row=mysqli_fetch_assoc($result);
$batchCount=$row["batchCount"];

if ($batchCount>0) {
    $_SESSION['error_msg']="Batch already exist";
    $conditionCheck=1;
}

if($conditionCheck==0){

if($Section!=""){

        mysqli_query($conn,"INSERT INTO `tblbatches` (`Batch`,`Section`,`Faculty`) VALUES ('$Batch','$Section','$Faculty')");
    $_SESSION['addmsg']="Succesfully Added Course";
}

else{
    if(mysqli_query($conn,"INSERT INTO `tblbatches` (`Batch`,`Section`,`Faculty`) VALUES ('$Batch','$Batch','$Faculty')"))
    {
      $_SESSION['addmsg']="Succesfully Added Course";
                    
     }
     
}
//delete batch
$result=mysqli_query($conn,"SELECT COUNT(DISTINCT(Batch)) as totalBatches FROM `tblbatches`");
$row=mysqli_fetch_assoc($result);
$totalBatches=$row["totalBatches"];

if($totalBatches>12){
$result=mysqli_query($conn,"SELECT MIN(Batch) as minBatch FROM tblbatches");
$row=mysqli_fetch_assoc($result);
$minBatch=$row["minBatch"];
    mysqli_query($conn,"DELETE FROM tblbatches WHERE Batch=$minBatch");
}
}

header('location:manage_batch.php');

                
}
?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Batches</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">Add New Batch</h6>
                </div>
                <div class="panel-body">
                    <div class="graph-standard" id="simple_graph">
                        
            <form class="form-horizontal" method="post" style="width: 400px; margin: auto;  " >
              <br>
              <br>
              <br>
                
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Batch: </label>
                            <div class="col-sm-8">
                                <input type="text" class="form-control" name="Batch" required="required">
                            </div>
                        </div> 
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Section: </label>
                            <div class="col-sm-8">                                
                            <input type="text" class="form-control" name="Section" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Faculty: </label>
                            <div class="col-sm-8">                                
                            <input type="text" class="form-control" name="Faculty" >
                            </div>
                        </div>                        
                          
                        <div class="text-right">
                            <input type="submit" name="add" value="ADD BATCH" class="btn btn-primary">
                        </div>
            </form>
                    </div>
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>
