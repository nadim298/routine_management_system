<div class="sidebar collapse">
        	<ul class="navigation">
            	<li class="active"><a href="dashboard.php"><i class="fa fa-laptop"></i> Dashboard</a></li>
                <li>
                    <a href="#" class="expand"><i class="fa fa-align-justify"></i> Batches</a>
                    <ul>
                        <li><a href="add_batches.php">Add Batch</a></li>
                        <li><a href="manage_batch.php">Manage Batches</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#" class="expand"><i class="fa fa-users"></i> Faculty</a>
                    <ul>
                        <li><a href="add_faculty.php">Add Faculty</a></li>
                        <li><a href="manage_faculty.php">Manage Faculty</a></li>
                    </ul>
                </li>
                

                <li><a href="all_batches_courses.php"><i class="fa fa-paste"></i> All Courses</a></li>
                <li><a href="editable_courses.php"><i class="fa fa-paste"></i> Edit Courses</a></li>
                <li><a href="start_trimester.php"><i class="fa fa-clock-o"></i> Start Trimester</a></li>
                <li><a href="All_Course_Choices.php"><i class="fa fa-check-square-o"></i> All Course Choices</a></li>
                <li><a href="AssignedCourses.php"><i class="fa fa-floppy-o"></i> Assigned Courses</a></li>
                <li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>
                <li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
            </ul>
        </div>