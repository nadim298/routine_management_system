<?php include 'includes/session.php';?>
<?php 
	$delete_query="DELETE FROM tblassignedcourses WHERE Session='$trimester_id'";
    mysqli_query($conn,$delete_query);

	$select_tblrequests=mysqli_query($conn,"SELECT * FROM tblrequests WHERE Session='$trimester_id' AND CourseCommon_ID<>'' ORDER BY Faculty_ID ASC"); 
	if(mysqli_num_rows($select_tblrequests)>0)
	{
		while($select_tblrequests_row=mysqli_fetch_array($select_tblrequests))
		{
			$Batch_No=$select_tblrequests_row["Batch_No"];
			$CourseCommon_ID=$select_tblrequests_row["CourseCommon_ID"];
			$Faculty_ID=$select_tblrequests_row["Faculty_ID"];
			//check designation
			$checkDesignation_cmd=mysqli_query($conn,"SELECT Designation_Id FROM `tblfaculty` WHERE id='$Faculty_ID'");
			$checkDesignation_row=mysqli_fetch_assoc($checkDesignation_cmd);
			$Designation_ID=$checkDesignation_row["Designation_Id"];
			
			if($Designation_ID==1){
				$select_tblbatches=mysqli_query($conn,"SELECT Section FROM `tblbatches` WHERE Batch='$Batch_No'"); 
			if(mysqli_num_rows($select_tblbatches)>0)
			{
				while($select_tblbatches_row=mysqli_fetch_array($select_tblbatches))
				{
					$Section=$select_tblbatches_row["Section"];
					//count number of faculty assigned
					$count_Faculty_ID_cmd=mysqli_query($conn,"SELECT COUNT(Faculty_ID) as count_Faculty_ID FROM tblassignedcourses WHERE Session='$trimester_id' AND Faculty_ID='$Faculty_ID'");
					$count_Faculty_ID_row=mysqli_fetch_assoc($count_Faculty_ID_cmd);
					$count_Faculty_ID=$count_Faculty_ID_row["count_Faculty_ID"];

					if($count_Faculty_ID<4){

						$count_Section_cmd=mysqli_query($conn,"SELECT COUNT(BatchSection) as count_Section FROM tblassignedcourses WHERE Session='$trimester_id' AND BatchSection='$Section' AND CourseCommon_ID='$CourseCommon_ID'");
					$count_Section_row=mysqli_fetch_assoc($count_Section_cmd);
					$count_Section=$count_Section_row["count_Section"];

					if($count_Section==0){
						$count_Course_cmd=mysqli_query($conn,"SELECT COUNT(CourseCommon_ID) as count_Course FROM tblcourses WHERE  CourseCommon_ID='$CourseCommon_ID'");
					$count_Course_row=mysqli_fetch_assoc($count_Course_cmd);
					$count_Course=$count_Course_row["count_Course"];
					$Count=$count_Course+$count_Faculty_ID;
					if($Count<=4){

						$select_CourseTheoryLab_cmd=mysqli_query($conn,"SELECT CourseTitle FROM `tblcourses` WHERE CourseCommon_ID='$CourseCommon_ID'"); 
						if(mysqli_num_rows($select_CourseTheoryLab_cmd)>0)
						{
							while($select_CourseTheoryLab_row=mysqli_fetch_array($select_CourseTheoryLab_cmd))
							{
								//final insert
								$CourseTitle=$select_CourseTheoryLab_row["CourseTitle"];
								mysqli_query($conn,"INSERT INTO `tblassignedcourses` ( `Faculty_ID`, `CourseCommon_ID`, `CourseTitle`, `BatchSection`, `Session`) VALUES ( '$Faculty_ID', '$CourseCommon_ID', '$CourseTitle', '$Section', '$trimester_id')");

							}
					}

					}
					}
					}

				}
			}
			}
			else{
				$select_tblbatches=mysqli_query($conn,"SELECT Section FROM `tblbatches` WHERE Batch='$Batch_No'"); 
			if(mysqli_num_rows($select_tblbatches)>0)
			{
				while($select_tblbatches_row=mysqli_fetch_array($select_tblbatches))
				{
					$Section=$select_tblbatches_row["Section"];
					//count number of faculty assigned
					$count_Faculty_ID_cmd=mysqli_query($conn,"SELECT COUNT(Faculty_ID) as count_Faculty_ID FROM tblassignedcourses WHERE Session='$trimester_id' AND Faculty_ID='$Faculty_ID'");
					$count_Faculty_ID_row=mysqli_fetch_assoc($count_Faculty_ID_cmd);
					$count_Faculty_ID=$count_Faculty_ID_row["count_Faculty_ID"];

					if($count_Faculty_ID<5){

						$count_Section_cmd=mysqli_query($conn,"SELECT COUNT(BatchSection) as count_Section FROM tblassignedcourses WHERE Session='$trimester_id' AND BatchSection='$Section' AND CourseCommon_ID='$CourseCommon_ID'");
					$count_Section_row=mysqli_fetch_assoc($count_Section_cmd);
					$count_Section=$count_Section_row["count_Section"];

					if($count_Section==0){
						$count_Course_cmd=mysqli_query($conn,"SELECT COUNT(CourseCommon_ID) as count_Course FROM tblcourses WHERE  CourseCommon_ID='$CourseCommon_ID'");
					$count_Course_row=mysqli_fetch_assoc($count_Course_cmd);
					$count_Course=$count_Course_row["count_Course"];
					$Count=$count_Course+$count_Faculty_ID;
					if($Count<=5){

						$select_CourseTheoryLab_cmd=mysqli_query($conn,"SELECT CourseTitle FROM `tblcourses` WHERE CourseCommon_ID='$CourseCommon_ID'"); 
						if(mysqli_num_rows($select_CourseTheoryLab_cmd)>0)
						{
							while($select_CourseTheoryLab_row=mysqli_fetch_array($select_CourseTheoryLab_cmd))
							{
								//final insert
								$CourseTitle=$select_CourseTheoryLab_row["CourseTitle"];
								mysqli_query($conn,"INSERT INTO `tblassignedcourses` ( `Faculty_ID`, `CourseCommon_ID`, `CourseTitle`, `BatchSection`, `Session`) VALUES ( '$Faculty_ID', '$CourseCommon_ID', '$CourseTitle', '$Section', '$trimester_id')");

							}
					}

					}
					}
					}

				}
			}
			}
			$_SESSION['msg_success']="Auto Assigned Successfull";
				header('location:AssignedCourses.php');			
		}
	}
 ?>