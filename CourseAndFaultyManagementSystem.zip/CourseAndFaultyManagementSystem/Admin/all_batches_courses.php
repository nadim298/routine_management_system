<?php include 'includes/session.php';?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
        	<div class="page-title">
                <h5><i class="fa fa-bars"></i>Courses</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">Courses Of all Batches</h6>
                </div>
                <div class="panel-body">
                	<div class="col-md-10" style="margin-left: 50px; margin-bottom:20px;">
                		<form method="post">
                			<div class="form-group">
                			<div class="col-md-2">
                				<label>Level:</label>
                               <select name="L" tabindex="2" class="" style="width: 30px;">
                                <option value="4">4</option>
                                <option value="3">3</option>
                                <option value="2">2</option>
                                <option value="1">1</option>                                
                            	</select>
                            </div>
                            <div class="col-md-2">
                            	<label>Term:</label>
                               <select name="T" tabindex="2" class="" style="width: 30px;">
                                <option value="3">3</option>
                                <option value="2">2</option>
                                <option value="1">1</option>                           
                            	</select>
                            </div>

                            <div class="col-md-2">
                               <input type="Submit" name="Search" value="Search">
                               <a href="all_batches_courses.php">Clear</a>
                            </div>
                            
                            </div>
                		</form>
                        <button class="pull-right" onclick="printHtmldiv();">Download PDF</button>
                	</div>

                    <div id="PDFDiv">
                        <?php 
                        
                        if(isset($_POST['Search']))
                        {
                            $L=$_POST['L'];
                            $T=$_POST['T'];
                            $select_level_id=mysqli_query($conn,"SELECT id FROM `tbllevel` WHERE Level=$L and Term=$T");
                            $select_level_id_row=mysqli_fetch_assoc($select_level_id);
                            $LevelId=$select_level_id_row["id"];

                            $BatchLavel= $LevelId-1;
                            //get batch number
                            $select_Batch=mysqli_query($conn,"SELECT Batch FROM `tblbatches` GROUP by Batch LIMIT $BatchLavel,1");
                            $select_Batch_row=mysqli_fetch_assoc($select_Batch);
                            $Batch=$select_Batch_row["Batch"];
                            //end get batch number
                            $select_section="SELECT Section,Faculty FROM `tblbatches` WHERE Batch=$Batch";
                                        $select_section_run=mysqli_query($conn,$select_section);              
                                            if(mysqli_num_rows($select_section_run)>0){
                                                while($select_section_row=mysqli_fetch_array($select_section_run)){
                                                    $Section=$select_section_row["Section"];
                                                    $Faculty=$select_section_row["Faculty"];

                                                    ?>
                                                    <div class="col-md-10" style="margin-left: 50px; margin-bottom:50px;" >
                                <div style="height: 30px; background: grey; font-weight: bold; padding: 5px; color: white;">
                                                            <div class="col-md-4">
                                                                <span>Batch: <?php echo $Section; ?></span>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <span><?php echo $Faculty; ?></span>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <span class="pull-right">L:<?php echo $L; ?>,T:<?php echo $T; ?></span>
                                                            </div>
                                                            
                                                        </div>
                            
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Code</th>
                                <th>Course Title</th>
                                <th>Credit Hour</th>
                                <th>Contact Hour</th>
                                <th>Pre-requisite</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $select_course="SELECT * FROM `tblcourses` WHERE LevelId=$LevelId";
                                                    $select_course_run=mysqli_query($conn,$select_course);              
                                                        if(mysqli_num_rows($select_course_run)>0){
                                                            while($select_course_row=mysqli_fetch_array($select_course_run)){
                                                                ?>
                                                                <tr>
                            <td><?php echo $select_course_row["SL"]; ?></td>
                            <td><?php echo $select_course_row["CourseCode"]; ?></td>
                            <td width="45%"><?php echo $select_course_row["CourseTitle"]; ?></td>
                            <td><?php echo $select_course_row["CreditHour"]; ?></td>
                            <td><?php echo $select_course_row["ContactHour"]; ?></td>
                            <td><?php echo $select_course_row["Pre-requisite"]; ?></td>
                           </tr>
                                                                <?php                                                               
                                                            }
                                                        }
                             ?>
                           
                        </tbody>
                    </table>
                </div>

                                                    <?php
                                                }
                                                $LevelId++;
                                            }


                        }
                        else{


                        $LevelId=1;

                        $select_batches="SELECT Batch FROM `tblbatches` GROUP by Batch";
                            $select_batches_run=mysqli_query($conn,$select_batches);              
                                if(mysqli_num_rows($select_batches_run)>0){
                                    while($select_batches_row=mysqli_fetch_array($select_batches_run)){
                                        $Batch=$select_batches_row["Batch"];

                                        //get level and term
                                            $get_levelTerm=mysqli_query($conn,"SELECT * FROM `tbllevel` WHERE id=$LevelId");
                                            $get_levelTerm_row=mysqli_fetch_assoc($get_levelTerm);
                                            $L=$get_levelTerm_row["Level"];
                                            $T=$get_levelTerm_row["Term"];
                                        //end get level and term
                                        

                                        $select_section="SELECT Section,Faculty FROM `tblbatches` WHERE Batch=$Batch";
                                        $select_section_run=mysqli_query($conn,$select_section);              
                                            if(mysqli_num_rows($select_section_run)>0){
                                                while($select_section_row=mysqli_fetch_array($select_section_run)){
                                                    $Section=$select_section_row["Section"];
                                                    $Faculty=$select_section_row["Faculty"];

                                                    ?>
                                                    <div class="col-md-10" style="margin-left: 50px; margin-bottom:50px;" >
                                                        <div style="height: 30px; background: grey; font-weight: bold; padding: 5px; color: white;">
                                                            <div class="col-md-4">
                                                                <span>Batch: <?php echo $Section; ?></span>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <span><?php echo $Faculty; ?></span>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <span class="pull-right">L:<?php echo $L; ?>,T:<?php echo $T; ?></span>
                                                            </div>
                                                            
                                                        </div>
                            
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Code</th>
                                <th>Course Title</th>
                                <th>Credit Hour</th>
                                <th>Contact Hour</th>
                                <th>Pre-requisite</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $select_course="SELECT * FROM `tblcourses` WHERE LevelId=$LevelId";
                                                    $select_course_run=mysqli_query($conn,$select_course);              
                                                        if(mysqli_num_rows($select_course_run)>0){
                                                            while($select_course_row=mysqli_fetch_array($select_course_run)){
                                                                ?>
                                                                <tr>
                            <td><?php echo $select_course_row["SL"]; ?></td>
                            <td><?php echo $select_course_row["CourseCode"]; ?></td>
                            <td width="45%"><?php echo $select_course_row["CourseTitle"]; ?></td>
                            <td><?php echo $select_course_row["CreditHour"]; ?></td>
                            <td><?php echo $select_course_row["ContactHour"]; ?></td>
                            <td><?php echo $select_course_row["Pre-requisite"]; ?></td>
                           </tr>
                                                                <?php                                                               
                                                            }
                                                        }
                             ?>
                           
                        </tbody>
                    </table>
                </div>

                                                    <?php
                                                }
                                                $LevelId++;
                                            }
                                    }
                                }
                            }
                     ?>
                    </div>
                    
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.0.272/jspdf.debug.js"></script>

<script type="text/javascript">
function printHtmldiv()
        {
            var pdf = new jsPDF('p', 'pt', 'letter')


            // source can be HTML-formatted string, or a reference
            // to an actual DOM element from which the text will be scraped.
            , source = $('#PDFDiv')[0]

            // we support special element handlers. Register them with jQuery-style
            // ID selector for either ID or node name. ("#iAmID", "div", "span" etc.)
            // There is no support for any other type of selectors
            // (class, of compound) at this time.
            , specialElementHandlers = {
                 // element with id of "bypass" - jQuery style selector
                '#bypassme': function(element, renderer)
                {
                    // true = "handled elsewhere, bypass text extraction"
                    return true
                }
            }

            margins = {
                top: 80,
                bottom: 60,
                left: 40,
                width: 522
            };
            $("table").css("font-size", "8px");
            // all coords and widths are in jsPDF instance's declared units
            // 'inches' in this case
            pdf.fromHTML
            (

                source // HTML string or DOM elem ref.
              , margins.left // x coord
              , margins.top // y coord
              , {'width': margins.width // max width of content on PDF
                 , 'elementHandlers': specialElementHandlers
                }
              , function (dispose) 
                {
                   // dispose: object with X, Y of the last line add to the PDF
                   // this allow the insertion of new lines after html
                   pdf.save('Mypdf.pdf');
                }
              , margins
            )
        }
</script>