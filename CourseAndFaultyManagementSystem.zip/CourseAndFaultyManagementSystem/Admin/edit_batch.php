<?php include 'includes/session.php';?>
<?php   
$Batch=$_GET['Batch'];
$Section=$_GET['Section'];
$query="SELECT * from tblbatches WHERE `tblbatches`.`Batch` = '$Batch' and `tblbatches`.`Section` = '$Section'";
$run=mysqli_query($conn,$query);
$row=mysqli_fetch_array($run);      
?>
        
 <?php
if(isset($_POST['update']))
{
$Batch=$_POST['Batch'];
$Section=$_POST['Section'];
$Faculty=$_POST['Faculty'];

$sql = "UPDATE `tblbatches` SET `Faculty` = '$Faculty' WHERE `tblbatches`.`Batch` = '$Batch' and `tblbatches`.`Section` = '$Section'";
if(mysqli_query($conn,$sql)){
                    $_SESSION['updatemsg']="Succesfully Updated Batch";
                    header('location:manage_batch.php');
                }
                
}
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
        
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Faculty</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">Update Faculty</h6>
                </div>
                <div class="panel-body">
                    <div class="" id="simple_graph">
                        
            <form class="form-horizontal" method="post" style="width: 400px; margin: auto;  " >
              <br>
              <br>
              <br>
                
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Batch: </label>
                            <div class="col-sm-10">
                                <input readonly type="text" class="form-control" name="Batch" value="<?php echo $row['Batch'];?>" required="required">
                            </div>
                        </div> 
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Section: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="Section" value="<?php echo $row['Section'];?>" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Adviser: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="Faculty" value="<?php echo $row['Faculty'];?>" required="required">
                            </div>
                        </div>
                                              
                          
                        <div class="text-right">
                            <input type="submit" name="update" value="UPDATE" class="btn btn-primary">
                        </div>
            </form>
                    </div>
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>