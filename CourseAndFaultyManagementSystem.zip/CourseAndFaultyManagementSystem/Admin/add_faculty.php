<?php include 'includes/session.php';?>
 <?php
if(isset($_POST['add']))
{
$Name=ucfirst($_POST['Name']);
$Designation_Id=$_POST['Designation_Id'];
$Email=$_POST['Email'];
$Password="Faculty123";

$sql = "INSERT INTO tblfaculty (Name, Designation_Id, Email, Password) VALUES ('$Name', '$Designation_Id','$Email', '$Password')";
if(mysqli_query($conn,$sql)){
                    $_SESSION['addmsg']="Succesfully Added Faculty";
                    header('location:manage_faculty.php');
                }
                
}
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
        	<div class="page-title">
                <h5><i class="fa fa-bars"></i>Faculty</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title">Add New Faculty</h6>
                </div>
                <div class="panel-body">
                    <div class="" id="simple_graph">
                        
            <form class="form-horizontal" method="post" style="width: 400px; margin: auto;  " >
              <br>
              <br>
              <br>
                
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Name: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="Name" value="" required="required" onkeyup="lettersOnly(this)">
                            </div>
                        </div>                        
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Designation: </label>
                            <div class="col-sm-10">
                                <select class="form-control" name="Designation_Id" required="required">
                                    <?php 
                                    $sql = "SELECT * from tbldsignation";
                                    $tbldsignation_run=mysqli_query($conn,$sql);
                                        if(mysqli_num_rows($tbldsignation_run)>0){
                                                                while($tbldsignation_row=mysqli_fetch_array($tbldsignation_run)){
                                                                    $id=$tbldsignation_row['id'];
                                                                    $Designation=$tbldsignation_row['Designation'];
                                       
                                        ?>  
                                    <option value="<?php echo htmlentities($id);?>"><?php echo htmlentities($Designation);?></option>
                                     <?php }} ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Email: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="Email" value="" required="required">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Password: </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" name="Password" value="Faculty123" readonly>
                            </div>
                        </div>   
                        <div class="text-right">
                            <input type="submit" name="add" value="ADD FACULTY" class="btn btn-primary">
                        </div>
            </form>
                    </div>
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>
