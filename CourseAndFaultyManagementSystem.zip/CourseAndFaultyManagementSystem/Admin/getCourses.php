<?php include 'includes/session.php';?>
<?php 
	$output="";
	$query="SELECT CourseCommon_ID FROM `tblcourses` where CourseCommon_ID<>'' GROUP by CourseCommon_ID";
	$run=mysqli_query($conn,$query); 
	if(mysqli_num_rows($run)>0)
	{
		$output .= "<option value=''></option>";
		while($row=mysqli_fetch_array($run))
		{
			$CourseCommon_ID=$row['CourseCommon_ID'];
			

		    $getCourseTitle=mysqli_query($conn,"SELECT CourseTitle FROM `tblcourses` WHERE CourseCommon_ID='$CourseCommon_ID' LIMIT 0,1");
		    $getCourseTitle_row=mysqli_fetch_array($getCourseTitle);

		    $output .= "<option value='".$CourseCommon_ID."'>".$getCourseTitle_row["CourseTitle"]."</option>";
		}
	}
	
	echo $output;
		
?>