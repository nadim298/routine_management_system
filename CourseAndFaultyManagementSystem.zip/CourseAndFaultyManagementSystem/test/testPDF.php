 
<?php 
	require_once 'dompdf/autoload.inc.php'; 
 
use Dompdf\Dompdf; 
 
$dompdf = new Dompdf();

//$dompdf->loadHtml('<h1>Welcome to CodexWorld.com</h1>'); 
$html = file_get_contents("Admin/add_batches.php"); 
$dompdf->loadHtml($html); 
 
$dompdf->setPaper('A4', 'landscape'); 
 
$dompdf->render(); 
 
$dompdf->stream();
 ?>