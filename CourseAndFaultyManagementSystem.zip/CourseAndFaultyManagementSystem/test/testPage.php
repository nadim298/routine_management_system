<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div id="HTMLtoPDF">This is for testing : div1</div>
	<div>This is for testing : div2</div>
	<a href="#" onclick="HTMLtoPDF()">Download PDF</a>
</body>
</html>

	<script src="js/htmlToPdfJs/jspdf.js"></script>
	<script src="js/htmlToPdfJs/jquery-2.1.3.js"></script>
	<script src="js/htmlToPdfJs/pdfFromHTML.js"></script>