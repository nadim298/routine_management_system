<?php
	require_once('../includes/db.php');
	ob_start();
	session_start();
	if(!isset($_SESSION['email'])){
		header("location:../index.php");
	}
else{
    
    //get faculty id
    $email=$_SESSION['email'];
    $faculty_sql="SELECT tblfaculty.*, tbldsignation.Designation FROM tblfaculty INNER JOIN tbldsignation on tblfaculty.Designation_Id=tbldsignation.id where email='$email'";
    //$faculty_sql="select id,Name from tblfaculty where email='$email'";
    $faculty_run=mysqli_query($conn,$faculty_sql);
    $faculty_row=mysqli_fetch_array($faculty_run);
    $faculty_id=$faculty_row['id'];
    $faculty_name=$faculty_row['Name'];
    $Designation=$faculty_row['Designation'];
    //end get faculty id

    //get trimester id
    $trimester_sql="select * from trimester where status='1'";    
    $trimester_run=mysqli_query($conn,$trimester_sql);    
    $trimester_row=mysqli_fetch_array($trimester_run);
    $trimester_id=$trimester_row['id'];
    $trimester_name=$trimester_row['session'];
    //end get trimester id

    $trimester_start_date=$trimester_row['start_date'];
    $trimesterr_end_date=$trimester_row['end_date'];

    $trimester_validity=0;

    $today = date("Y-m-d");

    if($today>=$trimester_start_date && $today<=$trimesterr_end_date){
        $trimester_validity=1;
    }

    $check_request_cmd=mysqli_query($conn,"SELECT * FROM `tblrequests` WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id'");

    $check_request=0;
    if(mysqli_num_rows($check_request_cmd)>0){
        $check_request=1;
    }

    $check_assignedCourse_cmd=mysqli_query($conn,"SELECT * FROM `tblassignedcourses` WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id'");

    $check_assignedCourse=0;
    if(mysqli_num_rows($check_assignedCourse_cmd)>0){
        $check_assignedCourse=1;
    }
    
}

					

?>