<div class="sidebar collapse">
        	<ul class="navigation">
            	<li class="active"><a href="dashboard.php"><i class="fa fa-laptop"></i> Dashboard</a></li>
            	<li><a href="Course_Choice.php"><i class="fa fa-check-square-o"></i>Submit Course Choice</a></li>
            	<li><a href="MyRoutine.php"><i class="fa fa-list-alt"></i>My Routine</a></li>
            	<li><a href="change_password.php"><i class="fa fa-key"></i> Change Password</a></li>
            	<li><a href="../logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                
            </ul>
        </div>