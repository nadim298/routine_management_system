<?php include 'includes/session.php';?>
<?php 

    if(isset($_POST['submit']))
{
    $ChoiceNo1=$_POST["ChoiceNo1"];
    $ChoiceNo2=$_POST["ChoiceNo2"];
    $ChoiceNo3=$_POST["ChoiceNo3"];
    $ChoiceNo4=$_POST["ChoiceNo4"];
    $ChoiceNo5=$_POST["ChoiceNo5"];

    $check_query=mysqli_query($conn,"SELECT * FROM `tblrequests` WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id'");
    if(mysqli_num_rows($check_query)>0){
        $check_status=1;
    }
    else{
$check_status=0;

            }

    for ($i=1; $i <= 5 ; $i++) {
        $CourseCommon_ID=$_POST["ChoiceNo".$i];
        //get batchID
            //get lvlID
        $lvlID_cmd=mysqli_query($conn,"SELECT LevelId FROM `tblcourses` WHERE CourseCommon_ID='$CourseCommon_ID' LIMIT 0,1");
        $lvlID_row=mysqli_fetch_assoc($lvlID_cmd);
        $LevelId=$lvlID_row["LevelId"];

                            $BatchLavel= $LevelId-1;
                            //get batch number
                            $select_Batch=mysqli_query($conn,"SELECT Batch FROM `tblbatches` GROUP by Batch LIMIT $BatchLavel,1");
                            $select_Batch_row=mysqli_fetch_assoc($select_Batch);
                            $Batch=$select_Batch_row["Batch"];

        //end get batchID
       $insert_sql = "INSERT INTO `tblrequests` ( `ChoiceNo`, `Faculty_ID`, `CourseCommon_ID`, `Batch_No`, `Session`) VALUES ('$i', '$faculty_id', '$CourseCommon_ID', '$Batch', '$trimester_id')";

       $update_sql="UPDATE tblrequests SET CourseCommon_ID='$CourseCommon_ID', Batch_No='$Batch' WHERE Faculty_ID='$faculty_id' AND ChoiceNo='$i'";

       if($check_status==0){
        mysqli_query($conn,$insert_sql);
       }
       else{
        mysqli_query($conn,$update_sql);
       }        
    }
            if(!empty($_POST['DayWithShift'])) {
                mysqli_query($conn,"DELETE FROM tblfaculty_offdaychoice WHERE Faculty_Id='$faculty_id' AND Session='$trimester_id'");

                foreach($_POST['DayWithShift'] as $selected) {
                    mysqli_query($conn,"INSERT INTO `tblfaculty_offdaychoice` (`DayWithShift`, `Session`, `Faculty_Id`) VALUES ('$selected', '$trimester_id', '$faculty_id');");
                }
            }
            header('location:Course_Choice.php');

}
 ?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<style type="text/css">
    hr {
    margin-top: 2px;
    margin-bottom: 2px;
    border: 0;
    border-top: 1px solid #eee;
}
</style>
<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
        
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Course Choices</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"></h6>
                </div>
                <div class="panel-body">
                    <?php 
                    if($trimester_validity==1){
                        ?>
                        <div class="datatable">
                        <form method="post">
                            <center>
                                <?php 
                                if($check_request==1){
                                    echo "<center>You have submitted your choice. You can update it!</center>";
                                }
                                 ?>
                                
                                <input class="btn btn-success" type="submit" name="submit" value="<?php if($check_request==1){echo "Update";} else echo "Submit";?>" class="btn btn-primary"">
                            </center>
                            <br>
                            <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Faculty Name</th>

                                <th>Theory Courses</th>
                                <th>Day</th>
                                <th style="text-align: center;">8:00am <br>
                                    To <br>
                                 1:00pm
                                </th>
                                <th style="text-align: center;">1:00pm <br>
                                    To <br>
                                6:00pm</th>
                                <th>Updated date</th>
                            </tr>
                        </thead>
                        <tbody>                           
                            <tr>
                                <td><?php echo $faculty_id; ?></td>
                                <td><?php echo $faculty_name; ?></td>
                                
                                <td>                                    
                                    <select class="getCourses" name="ChoiceNo1" id="ChoiceNo1">
                                        
                                        
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo2" id="ChoiceNo2">
                                        
                                    </select><br>
                                    <select class="getTheoryCourses" name="ChoiceNo3" id="ChoiceNo3" required="required">
                                        
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo4" id="ChoiceNo4">
                                        
                                    </select><br>
                                    <select class="getCourses" name="ChoiceNo5" id="ChoiceNo5">
                                        
                                    </select>
                                </td>
                                <td>
                                    Saturday <hr>
                                    Sunday <hr>
                                    Monday <hr>
                                    Tuesday <hr>
                                    Wednesday <hr>
                                    Thursday
                                </td>
                                <td class="working_chk" style="text-align: center;">
                                    <input  type="checkbox" name="DayWithShift[]" value="Saturday-1"><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Sunday-1"><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Monday-1"><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Tuesday-1"><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Wednesday-1"><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Thursday-1"><br>
                                </td>
                                <td class="working_chk" style="text-align: center;">
                                    <input  type="checkbox" name="DayWithShift[]" value="Saturday-2"><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Sunday-2"><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Monday-2"><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Tuesday-2"><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Wednesday-2"><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Thursday-2"><br>
                                </td>
                                <td></td>
                            </tr>

                            <!-- other faculty -->
                             <?php 
                         $select_choiceRequest=mysqli_query($conn,"SELECT tblrequests.Faculty_ID, tblfaculty.Name FROM tblrequests INNER JOIN tblfaculty ON tblrequests.Faculty_ID=tblfaculty.id where Session='$trimester_id' and tblrequests.Faculty_ID<>'$faculty_id' GROUP by tblrequests.Faculty_ID");              
                                            if(mysqli_num_rows($select_choiceRequest)>0){
                                                while($select_choiceRequest_row=mysqli_fetch_array($select_choiceRequest)){
                                                    $Faculty_ID=$select_choiceRequest_row["Faculty_ID"];
                                                    $Name=$select_choiceRequest_row["Name"];

                                                 $DayWithShift1="";   
                                                 $DayWithShift2="";   
                                                 $DayWithShift_Count=1;   
        $select_DayWithShift=mysqli_query($conn,"SELECT * FROM `tblfaculty_offdaychoice` WHERE Faculty_Id='$Faculty_ID' AND Session='$trimester_id'");              
                                if(mysqli_num_rows($select_DayWithShift)>0){
                                    while($select_DayWithShift_row=mysqli_fetch_array($select_DayWithShift)){
                                        ${"DayWithShift" . $DayWithShift_Count}=$select_DayWithShift_row["DayWithShift"];
                                        $DayWithShift_Count=$DayWithShift_Count+1;
                                    }
                                }
     
                                                    ?>
                                                    <tr id="Other_Faculty_Tr">
                                <td><?php echo $Faculty_ID; ?></td>
                                <td><?php echo $Name; ?></td>
                                
                                <td>
                                    <select class="" name="" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo1_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=1 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo1_row=mysqli_fetch_array($ChoiceNo1_cmd);
                                        $ChoiceNo1=$ChoiceNo1_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo1; ?></option>
                                    </select><br>
                                    <select class="" name="" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo2_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=2 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo2_row=mysqli_fetch_array($ChoiceNo2_cmd);
                                        $ChoiceNo2=$ChoiceNo2_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo2; ?></option>
                                    </select><br>
                                    <select class="" name="" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo3_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=3 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo3_row=mysqli_fetch_array($ChoiceNo3_cmd);
                                        $ChoiceNo3=$ChoiceNo3_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo3; ?></option>
                                    </select><br>
                                    <select class="" name="" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo4_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID' and ChoiceNo=4 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo4_row=mysqli_fetch_array($ChoiceNo4_cmd);
                                        $ChoiceNo4=$ChoiceNo4_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo4; ?></option>
                                    </select><br>
                                    <select class="" name="" style="width: 200px;">
                                        <?php 
                                        $ChoiceNo5_cmd=mysqli_query($conn,"SELECT tblrequests.CourseCommon_ID,tblcourses.CourseTitle FROM tblrequests INNER JOIN tblcourses on tblrequests.CourseCommon_ID=tblcourses.CourseCommon_ID WHERE Faculty_ID='$Faculty_ID'   and ChoiceNo=5 and tblrequests.CourseCommon_ID<>'' LIMIT 0,1");
                                        $ChoiceNo5_row=mysqli_fetch_array($ChoiceNo5_cmd);
                                        $ChoiceNo5=$ChoiceNo5_row['CourseTitle'];
                                         ?>
                                         <option><?php echo $ChoiceNo5; ?></option>
                                    </select>
                                </td>
                                <td>
                                    Saturday <hr>
                                    Sunday <hr>
                                    Monday <hr>
                                    Tuesday <hr>
                                    Wednesday <hr>
                                    Thursday
                                </td>
                                <td style="text-align: center;">
                                    <input type="checkbox" disabled name="" value="Saturday-1" <?php if($DayWithShift1=="Saturday-1"|| $DayWithShift2=="Saturday-1"){ echo "checked";} ?>
                                    ><br>
                                    <input type="checkbox" disabled name="" value="Sunday-1" <?php if($DayWithShift1=="Sunday-1"|| $DayWithShift2=="Sunday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" disabled name="" value="Monday-1" <?php if($DayWithShift1=="Monday-1"|| $DayWithShift2=="Monday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" disabled name="" value="Tuesday-1" <?php if($DayWithShift1=="Tuesday-1"|| $DayWithShift2=="Tuesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" disabled name="" value="Wednesday-1" <?php if($DayWithShift1=="Wednesday-1"|| $DayWithShift2=="Wednesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" disabled name="" value="Thursday-1" <?php if($DayWithShift1=="Thursday-1"|| $DayWithShift2=="Thursday-1"){ echo "checked";} ?>><br>
                                </td>
                                <td style="text-align: center;">
                                    <input  type="checkbox" disabled name="" value="Saturday-2" <?php if($DayWithShift1=="Saturday-2"|| $DayWithShift2=="Saturday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" disabled name="" value="Sunday-2" <?php if($DayWithShift1=="Sunday-2"|| $DayWithShift2=="Sunday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" disabled name="" value="Monday-2" <?php if($DayWithShift1=="Monday-2"|| $DayWithShift2=="Monday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" disabled name="" value="Tuesday-2" <?php if($DayWithShift1=="Tuesday-2"|| $DayWithShift2=="Tuesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" disabled name="" value="Wednesday-2" <?php if($DayWithShift1=="Wednesday-2"|| $DayWithShift2=="Wednesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" disabled name="" value="Thursday-2" <?php if($DayWithShift1=="Thursday-2"|| $DayWithShift2=="Thursday-2"){ echo "checked";} ?>><br>
                                </td>
                                <td></td>
                            </tr>
                                                    <?php
                                                }
                                            }
                          ?> 
                            
                        </tbody>
                    </table>
                    
                        </form>
                    
                </div>
                <?php
                    }
                    else{
                        ?>
                        <div style="text-align: center">
                        <h3 style="color: red;">Choice submission is closed now!</h3>
                        <a  href="MyRoutine.php">See Your Routine</a>
                        </div>
                        <?php
                    }
                     ?>
                    
                    
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>
<script type="text/javascript">
    $(document).ready(function($) {
        $.ajax({
            url: 'getCourses.php',
            method: "post",
            data: {},
            success: function(data){
                $(".getCourses").html(data);


                 <?php 
                        $ChoiceNo_cmd=mysqli_query($conn,"SELECT (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=1) as ChoiceNo1,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=2) as ChoiceNo2,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=3) as ChoiceNo3,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=4) as ChoiceNo4,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=5) as ChoiceNo5");
                                    if(mysqli_num_rows($ChoiceNo_cmd)>0){
                                        $ChoiceNo_row=mysqli_fetch_array($ChoiceNo_cmd);

                                        $ChoiceNo1=$ChoiceNo_row['ChoiceNo1'];
                                        $ChoiceNo2=$ChoiceNo_row['ChoiceNo2'];
                                        $ChoiceNo3=$ChoiceNo_row['ChoiceNo3'];
                                        $ChoiceNo4=$ChoiceNo_row['ChoiceNo4'];
                                        $ChoiceNo5=$ChoiceNo_row['ChoiceNo5'];
                                    
                                     ?>
            $("#ChoiceNo1").val("<?php echo $ChoiceNo1; ?>");
            $("#ChoiceNo2").val("<?php echo $ChoiceNo2; ?>");
            $("#ChoiceNo3").val("<?php echo $ChoiceNo3; ?>");
            $("#ChoiceNo4").val("<?php echo $ChoiceNo4; ?>");
            $("#ChoiceNo5").val("<?php echo $ChoiceNo5; ?>");
        <?php 
            } 
        ?>
            }
        })
    
});

    $(document).ready(function($) {
        $.ajax({
            url: 'getTheoryCourses.php',
            method: "post",
            data: {},
            success: function(data){
                $(".getTheoryCourses").html(data);

                <?php 
                        $ChoiceNo_cmd=mysqli_query($conn,"SELECT (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=1) as ChoiceNo1,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=2) as ChoiceNo2,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=3) as ChoiceNo3,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=4) as ChoiceNo4,
                                                             (SELECT CourseCommon_ID FROM tblrequests WHERE Faculty_ID='$faculty_id' AND Session='$trimester_id' AND ChoiceNo=5) as ChoiceNo5");
                                    if(mysqli_num_rows($ChoiceNo_cmd)>0){
                                        $ChoiceNo_row=mysqli_fetch_array($ChoiceNo_cmd);

                                        $ChoiceNo1=$ChoiceNo_row['ChoiceNo1'];
                                        $ChoiceNo2=$ChoiceNo_row['ChoiceNo2'];
                                        $ChoiceNo3=$ChoiceNo_row['ChoiceNo3'];
                                        $ChoiceNo4=$ChoiceNo_row['ChoiceNo4'];
                                        $ChoiceNo5=$ChoiceNo_row['ChoiceNo5'];
                                    
                                     ?>
            $("#ChoiceNo1").val("<?php echo $ChoiceNo1; ?>");
            $("#ChoiceNo2").val("<?php echo $ChoiceNo2; ?>");
            $("#ChoiceNo3").val("<?php echo $ChoiceNo3; ?>");
            $("#ChoiceNo4").val("<?php echo $ChoiceNo4; ?>");
            $("#ChoiceNo5").val("<?php echo $ChoiceNo5; ?>");
        <?php 
            } 
        ?>
            }
                })
    
});
</script>

<script type="text/javascript">
$('.working_chk input[type=checkbox]').on('change', function (e) {
    if ($('.working_chk input[type=checkbox]:checked').length > 2) {
        $(this).prop('checked', false);
        alert("allowed only 2");
    }
});
</script>
<script type="text/javascript">
    <?php 
        $select_DayWithShift=mysqli_query($conn,"SELECT * FROM `tblfaculty_offdaychoice` WHERE Faculty_Id='$faculty_id' AND Session='$trimester_id'");              
                                if(mysqli_num_rows($select_DayWithShift)>0){
                                    while($select_DayWithShift_row=mysqli_fetch_array($select_DayWithShift)){
                                        $DayWithShift=$select_DayWithShift_row["DayWithShift"];
                                        ?>
                                        $('.working_chk input:checkbox[value=<?php echo $DayWithShift; ?>]').prop("checked",true);
                                        <?php
                                    }
                                }
     ?>
     
</script>
<!-- <script type="text/javascript">
    var ChoicesArray = [];
    function PushToArray(){
        if($( "#ChoiceNo1" ).val()!=""){        
        ChoicesArray.push($( "#ChoiceNo1" ).val());
        
    }
    if($( "#ChoiceNo2" ).val()!=""){
        ChoicesArray.push($( "#ChoiceNo2" ).val());        
    }
    if($( "#ChoiceNo3" ).val()!=""){
        ChoicesArray.push($( "#ChoiceNo3" ).val());        
    }
    if($( "#ChoiceNo4" ).val()!=""){
        ChoicesArray.push($( "#ChoiceNo4" ).val());        
    }
    if($( "#ChoiceNo5" ).val()!=""){
        ChoicesArray.push($( "#ChoiceNo5" ).val());        
    }

    }
    function DisableSelected(){
                var select = $(".getCourses");
                select.find("option:disabled").attr("disabled",false)
            jQuery.each( ChoicesArray, function( i, val ) {
                
              $('.getCourses').children('option[value="' + val + '"]').attr('disabled', true);
            });
    }

    $( "#ChoiceNo1" ).change(function() {
        PushToArray();
        DisableSelected();
        //alert(ChoicesArray);
        // $('#ChoiceNo2').children('option[value="' + $( "#ChoiceNo1" ).val() + '"]').attr('disabled', true)
    });
</script> -->