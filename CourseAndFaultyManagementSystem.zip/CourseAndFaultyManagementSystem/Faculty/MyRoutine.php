<?php include 'includes/session.php';?>
<?php
    $checkString=0; 
    $check_hasRoutine=mysqli_query($conn,"SELECT * FROM `tblassignedcourses` WHERE Faculty_ID='$faculty_id' and Session='$trimester_id'"); 
                            if(mysqli_num_rows($check_hasRoutine)>0)
                            {
                                $checkString=1; 
                            }
 ?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>
<style type="text/css">
    hr {
    margin-top: 2px;
    margin-bottom: 2px;
    border: 0;
    border-top: 1px solid #eee;
}
</style>
<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
    	
    	<!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
        	<div class="page-title">
                <h5><i class="fa fa-bars"></i>Choices</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading"><h6 class="panel-title">My Routine of <span style="color: red;"><?php echo $trimester_name; ?></span></h6>
                
                </div>
                <?php 
                    if($checkString==1){
                        ?>
                        <div class="datatable">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Faculty Name</th>
                                <th>Theory Courses</th>
                                <th>Day</th>
                                <th style="text-align: center;">8:00am <br>
                                    To <br>
                                 1:00pm
                                </th>
                                <th style="text-align: center;">1:00pm <br>
                                    To <br>
                                6:00pm</th>
                                <th>Updated date</th>
                            </tr>
                        </thead>
                         <tbody>  
                         <?php 
                         

                                                 $DayWithShift1="";   
                                                 $DayWithShift2="";   
                                                 $DayWithShift_Count=1;   
        $select_DayWithShift=mysqli_query($conn,"SELECT * FROM `tblfaculty_offdaychoice` WHERE Faculty_Id='$faculty_id' AND Session='$trimester_id'");              
                                if(mysqli_num_rows($select_DayWithShift)>0){
                                    while($select_DayWithShift_row=mysqli_fetch_array($select_DayWithShift)){
                                        ${"DayWithShift" . $DayWithShift_Count}=$select_DayWithShift_row["DayWithShift"];
                                        $DayWithShift_Count=$DayWithShift_Count+1;
                                    }
                                }
     
                                                    ?>
                                                    <tr>
                                <td><?php echo $faculty_id; ?></td>
                                <td><?php echo $faculty_name; ?></td>
                                
                                <td>
                                    
                                       <?php 
                            $select_routine=mysqli_query($conn,"SELECT * FROM `tblassignedcourses` WHERE Faculty_ID='$faculty_id' and Session='$trimester_id'"); 
                            if(mysqli_num_rows($select_routine)>0)
                            {
                                while($select_routine_row=mysqli_fetch_array($select_routine))
                                {
                                    ?>
                                    <select class="" name="" style="width: 300px;">
                                        <option><?php echo $select_routine_row["CourseTitle"]; ?></option>
                                        </select>
                                        <label>------ <?php echo $select_routine_row["BatchSection"]; ?></label>
                                         <br>                          
                            
                                    <?php

                                }
                            }
                          ?>
                                         
                                    
                                </td>
                                <td>
                                    Saturday <hr>
                                    Sunday <hr>
                                    Monday <hr>
                                    Tuesday <hr>
                                    Wednesday <hr>
                                    Thursday
                                </td>
                                <td style="text-align: center;">
                                    <input type="checkbox" name="DayWithShift[]" value="Saturday-1" <?php if($DayWithShift1=="Saturday-1"|| $DayWithShift2=="Saturday-1"){ echo "checked";} ?>
                                    ><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Sunday-1" <?php if($DayWithShift1=="Sunday-1"|| $DayWithShift2=="Sunday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Monday-1" <?php if($DayWithShift1=="Monday-1"|| $DayWithShift2=="Monday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Tuesday-1" <?php if($DayWithShift1=="Tuesday-1"|| $DayWithShift2=="Tuesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Wednesday-1" <?php if($DayWithShift1=="Wednesday-1"|| $DayWithShift2=="Wednesday-1"){ echo "checked";} ?>><br>
                                    <input type="checkbox" name="DayWithShift[]" value="Thursday-1" <?php if($DayWithShift1=="Thursday-1"|| $DayWithShift2=="Thursday-1"){ echo "checked";} ?>><br>
                                </td>
                                <td style="text-align: center;">
                                    <input  type="checkbox" name="DayWithShift[]" value="Saturday-2" <?php if($DayWithShift1=="Saturday-2"|| $DayWithShift2=="Saturday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Sunday-2" <?php if($DayWithShift1=="Sunday-2"|| $DayWithShift2=="Sunday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Monday-2" <?php if($DayWithShift1=="Monday-2"|| $DayWithShift2=="Monday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Tuesday-2" <?php if($DayWithShift1=="Tuesday-2"|| $DayWithShift2=="Tuesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Wednesday-2" <?php if($DayWithShift1=="Wednesday-2"|| $DayWithShift2=="Wednesday-2"){ echo "checked";} ?>><br>
                                    <input  type="checkbox" name="DayWithShift[]" value="Thursday-2" <?php if($DayWithShift1=="Thursday-2"|| $DayWithShift2=="Thursday-2"){ echo "checked";} ?>><br>
                                </td>
                                <td></td>
                            </tr>
                                                                            
                            
                            
                        </tbody>
                    </table>
                </div>
                        <?php
                    }
                    else{
                        echo "<center>Not yet assigned</center>";
                    }
                 ?>
                
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>
<script type="text/javascript">
$('input[type=checkbox]').prop('disabled', true);
</script>