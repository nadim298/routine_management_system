<?php include 'includes/session.php';?>


<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from demo.interface.club/itsbrain/liquid/light/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 31 May 2019 12:02:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<?php include '../includes/head.php';?>

<body>
    <!-- Page header -->
    <?php include '../includes/header.php';?>
    <!-- /page header -->


    <!-- Page container -->
    <div class="page-container container-fluid">
        
        <!-- Sidebar -->
        <?php include 'includes/sidebar.php';?>
        <!-- /sidebar -->

    
        <!-- Page content -->
        <div class="page-content">

            <!-- Page title -->
            <div class="page-title">
                <h5><i class="fa fa-bars"></i>Dashboard</h5>
            </div>
            <!-- /page title -->

                
            <!-- Simple chart -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h6 class="panel-title"></h6>
                </div>
                <div class="panel-body">
                    <div class="graph-standard" id="simple_graph" style="text-align: center; font-size: large;">
                        <table class="table table-borderless">
                            <tr>
                                <td style="text-align: right;">Name:</td>
                                <td style="text-align: left;"><?php echo $faculty_name; ?> <br></td>
                            </tr>
                            <tr>
                                <td style="text-align: right;">Designation:</td>
                                <td style="text-align: left;"><?php echo $Designation; ?></td>
                            </tr>
                        </table>
                         
                         
                    </div>
                </div>
            </div>
            <!-- /simple chart -->

            <!-- Footer -->
            <?php include '../includes/footer.php';?>
            <!-- /footer -->

        </div>
    </div>

</body>
</html>
