-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 18, 2020 at 05:54 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_and_faculty_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', '404nadim@gmail.com', '3fb355dd9a16b859db904fa346a26d64');

-- --------------------------------------------------------

--
-- Table structure for table `tblassignedcourses`
--

CREATE TABLE `tblassignedcourses` (
  `id` int(11) NOT NULL,
  `Faculty_ID` int(11) NOT NULL,
  `CourseCommon_ID` varchar(20) NOT NULL,
  `CourseTitle` varchar(100) NOT NULL,
  `BatchSection` varchar(20) NOT NULL,
  `Session` varchar(50) NOT NULL,
  `Created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblbatches`
--

CREATE TABLE `tblbatches` (
  `Batch` int(11) NOT NULL,
  `Section` varchar(10) NOT NULL,
  `Faculty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbatches`
--

INSERT INTO `tblbatches` (`Batch`, `Section`, `Faculty`) VALUES
(51, '51', 'Faculty5'),
(52, '52', 'Faculty 52'),
(53, '53-A', 'Faculty 53-A'),
(53, '53-B', 'Faculty 53-B'),
(54, '54', 'Faculty 54'),
(55, '55-A', 'Faculty 55-A'),
(55, '55-B', 'Faculty 55-B'),
(56, '56', 'Faculty 56'),
(57, '57-A', 'Faculty 57-A'),
(57, '57-B', 'Faculty 57-B'),
(57, '57-C', 'Zunayed'),
(58, '58', 'Faculty 58'),
(59, '59-A', 'Faculty 59-A'),
(59, '59-B', 'Faculty 59-B'),
(60, '60', 'Faculty 60'),
(61, '61', 'Faculty 61'),
(62, '62', 'Faculty 62');

-- --------------------------------------------------------

--
-- Table structure for table `tblcourses`
--

CREATE TABLE `tblcourses` (
  `id` int(11) NOT NULL,
  `CourseCommon_ID` varchar(20) NOT NULL,
  `SL` varchar(10) NOT NULL,
  `CourseCode` varchar(10) NOT NULL,
  `CourseTitle` varchar(100) NOT NULL,
  `CreditHour` varchar(20) NOT NULL,
  `ContactHour` varchar(20) NOT NULL,
  `Pre-requisite` varchar(20) NOT NULL,
  `LevelId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcourses`
--

INSERT INTO `tblcourses` (`id`, `CourseCommon_ID`, `SL`, `CourseCode`, `CourseTitle`, `CreditHour`, `ContactHour`, `Pre-requisite`, `LevelId`) VALUES
(1, 'CPI', '1.', 'CSE 333', 'Computer Peripherals & Interfacing ', '3.00', '3.00 - 0.00', '', 1),
(2, 'CPI', '2.', 'CSE 334', 'Computer Peripherals & Interfacing Sessional', '1.50', '0.00 - 3.00', '', 1),
(3, 'ISM', '3.', 'CSI 439', 'Information System Management', '3.00', '3.00 - 0.00', '', 1),
(4, 'PO', '4.', 'ORE 103', 'Professional Orientation', '1.50', '', '', 1),
(5, 'Project', '5.', 'CSE 400', 'Project & Thesis', 'Continuation', '', '', 1),
(6, '', '', '', 'Total Credit Hour', '9.00+', '6.00 - 3.00+', '', 1),
(7, 'CG', '1.', 'CSI 413', 'Computer Graphics', '3.00', '3.00 - 0.00', '', 2),
(8, 'CG', '2.', 'CSI 414', 'Computer Graphics Sessional', '1.50', '0.00 - 3.00', '', 2),
(9, 'ML', '3.', 'CSI 483', 'Machine Learning', '3.00', '3.00 - 0.00', '', 2),
(10, 'Project', '4.', 'CSE 400', 'Project & Thesis', 'Continuation', '', '', 2),
(11, '', '', '', 'Total Credit Hour', '7.50+', '6.00 - 3.00+', '', 2),
(12, 'COMP', '1.', 'CSI 411', 'Compiler', '3.00', '3.00 - 0.00', '', 3),
(13, 'COMP', '2.', 'CSI 412', 'Compiler Sessional', '1.50', '0.00 - 3.00', '', 3),
(14, 'VIP', '3.', 'CSI 311', 'Visual and Internet Programming', '3.00', '3.00 - 0.00', 'CSI 217', 3),
(15, 'VIP', '4.', 'CSI 312', 'CSI 312	Visual and Internet Programming Sessional', '1.50', '0.00 - 3.00', '', 3),
(16, 'Project', '5.', 'CSE 400', 'Project & Thesis', '5.50', '', '', 3),
(17, '', '', '', 'Total Credit Hour', '14.50-', '6.00 - 6.00+', '', 3),
(18, 'ML2', '1.', 'CSI 483', 'Machine Learning', '3.00', '3.00 - 0.00', '', 4),
(19, 'SE', '2.', 'CSI 331', 'Software Engineering ', '3.00', '3.00 - 0.00', '', 4),
(20, 'SE', '3.', 'CSI 332', 'Software Engineering Sessional', '1.50', '0.00 - 3.00', '', 4),
(21, 'OS', '4.', 'CSI 313', 'Operating System', '3.00', '3.00 - 0.00', '', 4),
(22, 'OS', '5.', 'CSI 314', 'Operating System Sessional', '1.50', '0.00 - 3.00', '', 4),
(23, '', '', '', 'Total Credit Hour', '12.00', '9.00 - 6.00', '', 4),
(24, 'MAC', '1.', 'MATH 337', 'Mathematical Analysis for Computer Science', '3.00', '3.00 - 0.00', 'MATH 113', 5),
(25, 'TWC', '2.', 'ENG 137', 'Technical Writing and Communication', '3.00', '3.00 - 0.00', '', 5),
(26, 'CN', '3.', 'CSE 415', 'Computer Network ', '3.00', '3.00 - 0.00', '', 5),
(27, 'CN', '4.', 'CSE 416', 'Computer Network Sessional', '1.50', '0.00 - 3.00', '', 5),
(28, 'SAD', '5.', 'CSI 323', 'System Analysis and Design ', '3.00', '3.00 - 0.00', '', 5),
(29, 'SAD', '6.', 'CSI 324', 'System Analysis and Design Sessional', '1.50', '0.00 - 3.00', '', 5),
(30, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 5),
(38, 'DC', '1.', 'CSE 335', 'Data Communication', '3.00', '3.00 - 0.00', '', 6),
(39, 'NM', '2.', 'MATH 327', 'Numerical Methods', '3.00', '3.00 - 0.00', '', 6),
(40, 'AI', '3.', 'CSI 421', 'Artificial Intelligence and Expert System', '3.00', '3.00 - 0.00', '', 6),
(41, 'AI', '4.', 'CSI 422', 'Artificial Intelligence and Expert System Sessional', '1.50', '0.00 - 3.00', '', 6),
(42, 'AP', '5.', 'CSI 233', 'Advanced Programming', '3.00', '3.00 - 0.00', 'CSI 217', 6),
(43, 'AP', '6.', 'CSI 234', 'Advanced Programming Sessional', '1.50', '0.00 - 3.00', '', 6),
(44, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 6),
(45, 'TOC', '1.', 'CSI 315', 'Theory of Computing', '3.00', '3.00 - 0.00', '', 7),
(46, 'FALT', '2.', 'MATH 319', 'Fourier Analysis and Laplace Transformation', '3.00', '3.00 - 0.00', 'MATH 113', 7),
(47, 'MI', '3.', 'CSE 327', 'Microprocessor and Interfacing', '3.00', '3.00 - 0.00', '', 7),
(48, 'MI', '4.', 'CSE 328', 'Microprocessor and  Interfacing Sessional', '1.50', '0.00 - 3.00', '', 7),
(49, 'DBMS', '5.', 'CSI 223', 'Database Management System', '3.00', '3.00 - 0.00', '', 7),
(50, 'DBMS', '6.', 'CSI 224', 'Database Management System Sessional', '1.50', '0.00 - 3.00', '', 7),
(51, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 7),
(52, 'ECN', '1.', 'ECON 319', 'Economics', '3.00', '3.00 - 0.00', '', 8),
(53, 'MDE', '2.', 'MATH 237', 'Matrix and Differential Equation', '3.00', '3.00 - 0.00', 'MATH 113', 8),
(54, 'COA', '3.', 'CSE 233', 'Computer Organization and Architecture', '3.00', '3.00 - 0.00', 'CSE 133', 8),
(55, 'COA', '4.', 'CSE 234', 'Computer Organization and Architecture Sessional', '1.50', '0.00 - 3.00', '', 8),
(56, 'ALG', '5.', 'CSI 231', 'Algorithms', '3.00', '3.00 - 0.00', 'CSI 123', 8),
(57, 'ALG', '6.', 'CSI 232', 'Algorithms Sessional', '1.50', '0.00 - 3.00', '', 8),
(58, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 8),
(59, 'ACC', '1.', 'ACCT 227', 'Accounting', '3.00', '3.00 - 0.00', '', 9),
(60, 'CGVC', '2.', 'MATH 225', 'Coordinate Geometry And Vector Calculus', '3.00', '3.00 - 0.00', 'MATH 113', 9),
(61, 'DEPT', '3.', 'CSE 213', 'Digital Electronics and Pulse Technique', '3.00', '3.00 - 0.00', 'EEE 195', 9),
(62, 'DEPT', '4.', 'CSE 214', 'Digital Electronics and Pulse Technique Sessional', '1.50', '0.00 - 3.00', '', 9),
(63, 'OOP', '5.', 'CSI 217', 'Object Oriented Programming', '3.00', '3.00 - 0.00', 'CSI 123', 9),
(64, 'OOP', '6.', 'CSI 218', 'Object Oriented Programming Sessional', '1.50', '0.00 - 3.00', '', 9),
(65, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 9),
(66, 'PS', '1.', 'ENGL 102', 'Public Speaking', '3.00', '3.00 - 0.00', '', 10),
(67, 'BS', '2.', 'SOC 113', 'Bangladesh Studies', '3.00', '3.00 - 0.00', '', 10),
(68, 'DLD', '3.', 'CSE 133', 'Digital Logic Design', '3.00', '3.00 - 0.00', '', 10),
(69, 'DLD', '4.', 'CSE 134', 'Digital Logic Design Sessional', '1.50', '0.00 - 3.00', '', 10),
(70, 'DS', '5.', 'CSI 221', 'Data Structure', '3.00', '3.00 - 0.00', 'CSI 123', 10),
(71, 'DS', '6.', 'CSI 222', 'Data Structure Sessional', '1.50', '0.00 - 3.00', '', 10),
(72, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 10),
(73, 'COM', '1.', 'ENGL 101', 'Composition', '3.00', '3.00 - 0.00', '', 11),
(74, 'DIC', '2.', 'MATH 113', 'Differential and Integral Calculus', '3.00', '3.00 - 0.00', '', 11),
(75, 'ELC', '3.', 'EEE 195', 'Electronics', '3.00', '3.00 - 0.00', 'EEE 193', 11),
(76, 'ELC', '4.', 'EEE 196', 'Electronics Sessional', '1.50', '0.00 - 3.00', '', 11),
(77, 'SPL', '5.', 'CSI 123', 'Structured Programming Language', '3.00', '3.00 - 0.00', 'CSI 115', 11),
(78, 'SPL', '6.', 'CSI 124', 'Structured Programming Language Sessional', '1.50', '0.00 - 3.00', '', 11),
(79, '', '', '', 'Total Credit Hour', '15.00', '12.00 - 6.00', '', 11),
(80, 'FO', '1.', 'ORE 101', 'Freshman Orientation', '0.50', '', '', 12),
(81, 'CO', '2.', 'ORE 102', 'Continuous Orientation', '2.00', '', '', 12),
(82, 'EF', '3.', 'ENGL 100', 'English Fundamentals', '3.00', '3.00 - 0.00', '', 12),
(83, 'DM', '4.', 'MATH 135', 'Discrete Mathematics', '3.00', '3.00 - 0.00', '', 12),
(84, 'PHY', '5.', 'PHY 217', 'Physics', '3.00', '3.00 - 0.00', '', 12),
(85, 'ECD', '6.', 'EEE 193', 'Electrical Circuit and Devices', '3.00', '3.00 - 0.00', '', 12),
(86, 'CPC', '7.', 'CSI 115', 'Computer and Programming Concept', '3.00', '3.00 - 0.00', '', 12),
(87, 'CPC', '8.', 'CSI 116', 'Computer and Programming Concept Sessional', '1.50', '0.00 - 3.00', '', 12),
(88, '', '', '', 'Total Credit Hour', '16.00/19.00+', '12.00+ - 3.00', '', 12);

-- --------------------------------------------------------

--
-- Table structure for table `tbldsignation`
--

CREATE TABLE `tbldsignation` (
  `id` int(11) NOT NULL,
  `Designation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldsignation`
--

INSERT INTO `tbldsignation` (`id`, `Designation`) VALUES
(1, 'A.Professor'),
(2, 'Sr.Lecturer'),
(3, 'Lecturer');

-- --------------------------------------------------------

--
-- Table structure for table `tblfaculty`
--

CREATE TABLE `tblfaculty` (
  `id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Designation_Id` varchar(100) DEFAULT NULL,
  `Joining_Date` date DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfaculty`
--

INSERT INTO `tblfaculty` (`id`, `Name`, `Designation_Id`, `Joining_Date`, `Email`, `Password`, `Created_At`) VALUES
(1, 'Tamanna Haque Nipa', '1', NULL, '1@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:00:57'),
(2, 'Tamjid Rahman', '2', NULL, '2@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:01:35'),
(3, 'Tarikuzzaman Emon', '1', NULL, '3@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:01:35'),
(4, 'Md. Shahedul Islam', '2', NULL, '4@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:01:58'),
(5, 'Nazia Hossain', '3', NULL, '5@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:01:58'),
(6, 'Zabir Haque', '3', NULL, '6@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(7, 'Israt Jahan Mouri', '3', NULL, '7@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(8, 'Shifat Sharmin Shapla', '3', NULL, '8@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(9, 'Mahfida Amjad Dipa', '3', NULL, '9@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(10, 'Md. Rayhan Ahmed', '3', NULL, '10@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(11, 'Tanveer Ahmed', '3', NULL, '11@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(12, 'Adnan Ferdous Ashrafi', '3', NULL, '12@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(13, 'Aiasha Siddika', '3', NULL, '13@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(14, 'Ahmed Abdal Shafi Rasel', '3', NULL, '14@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(15, 'Md. Towhidul Islam Robin', '3', NULL, '15@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(16, 'Samia Sultana', '3', NULL, '16@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(17, 'Samiul Islam', '3', NULL, '17@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(18, 'Md. Biplob Hosen', '3', NULL, '18@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(19, 'Ashfaq Ali Shafin', '3', NULL, '19@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(20, 'Mehedi Hasan', '3', NULL, '20@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01'),
(21, 'Nusrat Jahan Farin', '3', NULL, '21@gmail.com', '4d813d28f0aaaa4e9da0fb6e55293607', '2020-01-06 05:05:01');

-- --------------------------------------------------------

--
-- Table structure for table `tblfaculty_offdaychoice`
--

CREATE TABLE `tblfaculty_offdaychoice` (
  `id` int(11) NOT NULL,
  `DayWithShift` varchar(50) NOT NULL,
  `Session` int(11) NOT NULL,
  `Faculty_Id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblfaculty_offdaychoice`
--

INSERT INTO `tblfaculty_offdaychoice` (`id`, `DayWithShift`, `Session`, `Faculty_Id`) VALUES
(13, 'Tuesday-1', 44, 1),
(14, 'Sunday-2', 44, 1),
(21, 'Sunday-1', 44, 2),
(22, 'Saturday-2', 44, 2),
(23, 'Sunday-1', 44, 3),
(24, 'Monday-1', 44, 3),
(25, 'Saturday-1', 45, 1),
(26, 'Sunday-1', 45, 1),
(29, 'Saturday-1', 45, 2),
(30, 'Sunday-2', 45, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbllevel`
--

CREATE TABLE `tbllevel` (
  `id` int(11) NOT NULL,
  `Level` int(11) NOT NULL,
  `Term` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbllevel`
--

INSERT INTO `tbllevel` (`id`, `Level`, `Term`) VALUES
(1, 4, 3),
(2, 4, 2),
(3, 4, 1),
(4, 3, 3),
(5, 3, 2),
(6, 3, 1),
(7, 2, 3),
(8, 2, 2),
(9, 2, 1),
(10, 1, 3),
(11, 1, 2),
(12, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblrequests`
--

CREATE TABLE `tblrequests` (
  `id` int(11) NOT NULL,
  `ChoiceNo` int(11) NOT NULL,
  `Faculty_ID` int(11) NOT NULL,
  `CourseCommon_ID` varchar(20) NOT NULL,
  `Batch_No` int(11) NOT NULL,
  `Session` varchar(20) NOT NULL,
  `Created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblrequests`
--

INSERT INTO `tblrequests` (`id`, `ChoiceNo`, `Faculty_ID`, `CourseCommon_ID`, `Batch_No`, `Session`, `Created_At`) VALUES
(249, 1, 8, 'COMP', 53, '47', '2020-02-18 17:48:51'),
(250, 2, 8, 'DBMS', 57, '47', '2020-02-18 17:48:51'),
(251, 3, 8, 'BS', 60, '47', '2020-02-18 17:48:51'),
(252, 4, 8, 'DC', 56, '47', '2020-02-18 17:48:51'),
(253, 5, 8, 'COA', 58, '47', '2020-02-18 17:48:51'),
(254, 1, 7, 'COMP', 53, '47', '2020-02-18 17:49:17'),
(255, 2, 7, 'CG', 52, '47', '2020-02-18 17:49:17'),
(256, 3, 7, 'ACC', 59, '47', '2020-02-18 17:49:17'),
(257, 4, 7, 'CN', 55, '47', '2020-02-18 17:49:17'),
(258, 5, 7, 'DBMS', 57, '47', '2020-02-18 17:49:17'),
(259, 1, 3, 'AI', 56, '47', '2020-02-18 17:50:00'),
(260, 2, 3, 'COA', 58, '47', '2020-02-18 17:50:00'),
(261, 3, 3, 'BS', 60, '47', '2020-02-18 17:50:00'),
(262, 4, 3, 'CN', 55, '47', '2020-02-18 17:50:00'),
(263, 5, 3, 'ALG', 58, '47', '2020-02-18 17:50:00'),
(264, 1, 1, 'AI', 56, '47', '2020-02-18 17:50:31'),
(265, 2, 1, 'ALG', 58, '47', '2020-02-18 17:50:31'),
(266, 3, 1, 'ACC', 59, '47', '2020-02-18 17:50:31'),
(267, 4, 1, 'COA', 58, '47', '2020-02-18 17:50:31'),
(268, 5, 1, 'CN', 55, '47', '2020-02-18 17:50:31');

-- --------------------------------------------------------

--
-- Table structure for table `trimester`
--

CREATE TABLE `trimester` (
  `id` int(11) NOT NULL,
  `session` varchar(50) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trimester`
--

INSERT INTO `trimester` (`id`, `session`, `start_date`, `end_date`, `status`) VALUES
(45, 'Spring 2020', '2020-01-17', '2020-01-20', 0),
(46, 'Summer 2020', '2020-02-15', '2020-02-17', 0),
(47, 'Fall 2020', '2020-02-18', '2020-02-20', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblassignedcourses`
--
ALTER TABLE `tblassignedcourses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbatches`
--
ALTER TABLE `tblbatches`
  ADD PRIMARY KEY (`Batch`,`Section`);

--
-- Indexes for table `tblcourses`
--
ALTER TABLE `tblcourses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldsignation`
--
ALTER TABLE `tbldsignation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblfaculty`
--
ALTER TABLE `tblfaculty`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `tblfaculty_offdaychoice`
--
ALTER TABLE `tblfaculty_offdaychoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbllevel`
--
ALTER TABLE `tbllevel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblrequests`
--
ALTER TABLE `tblrequests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trimester`
--
ALTER TABLE `trimester`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblassignedcourses`
--
ALTER TABLE `tblassignedcourses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `tblcourses`
--
ALTER TABLE `tblcourses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `tbldsignation`
--
ALTER TABLE `tbldsignation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblfaculty`
--
ALTER TABLE `tblfaculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblfaculty_offdaychoice`
--
ALTER TABLE `tblfaculty_offdaychoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbllevel`
--
ALTER TABLE `tbllevel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblrequests`
--
ALTER TABLE `tblrequests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=269;

--
-- AUTO_INCREMENT for table `trimester`
--
ALTER TABLE `trimester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
